#!/bin/sh
_bashish_defaults()
{
TITLE=$USER@`hostname`
}