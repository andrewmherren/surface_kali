#!/bin/sh
_bashish_overrides()
{
## override prompt stuff here
:
}